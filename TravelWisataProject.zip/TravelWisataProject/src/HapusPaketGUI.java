import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class HapusPaketGUI extends JFrame {

    private JTextField idField;

    public HapusPaketGUI() {
        setTitle("Hapus Paket Wisata");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(2, 2));

        JLabel idLabel = new JLabel("ID Paket:");
        idField = new JTextField();
        panel.add(idLabel);
        panel.add(idField);

        JButton hapusButton = new JButton("Hapus Paket");
        hapusButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                hapusPaket();
            }
        });
        panel.add(hapusButton);

        add(panel);
        setVisible(true);
    }

    private void hapusPaket() {
        try {
            String id = idField.getText();

            String url = "http://localhost:8000/hapuspaket/" + id;
            URL serverUrl = new URL(url);
            HttpURLConnection connection = (HttpURLConnection) serverUrl.openConnection();
            connection.setRequestMethod("DELETE");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String response = reader.readLine();
            reader.close();

            JOptionPane.showMessageDialog(this, response, "Hapus Paket", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Terjadi kesalahan: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new HapusPaketGUI();
            }
        });
    }
}
