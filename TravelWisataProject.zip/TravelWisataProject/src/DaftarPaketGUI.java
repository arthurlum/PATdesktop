import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class DaftarPaketGUI extends JFrame {

    private DefaultTableModel model;

    public DaftarPaketGUI() {
        // Setting frame
        setTitle("Daftar Paket Wisata");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel utama
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        // Tabel untuk menampilkan data
        JTable table = new JTable();
        model = new DefaultTableModel();
        model.addColumn("Username");
        model.addColumn("Password");
        model.addColumn("Harga Paket");
        model.addColumn("Jenis Trip");
        model.addColumn("List Wisata");
        table.setModel(model);

        // Scroll pane untuk tabel
        JScrollPane scrollPane = new JScrollPane(table);

        // Tombol untuk memperbarui data
        JButton btnRefresh = new JButton("Refresh");
        btnRefresh.addActionListener(e -> {
            // Memperbarui data ketika tombol ditekan
            tampilkanData();
        });

        // Panel untuk tombol
        JPanel panelTombol = new JPanel();
        panelTombol.add(btnRefresh);

        // Menambahkan komponen ke panel utama
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(panelTombol, BorderLayout.SOUTH);

        // Menambahkan panel ke frame
        add(panel);

        // Menampilkan frame
        setVisible(true);

        // Menampilkan data saat aplikasi pertama kali dibuka
        tampilkanData();
    }

    private void tampilkanData() {
        try {
            // URL server
            String url = "http://localhost:8000/daftarpaket"; // Ganti port dengan port server Anda
    
            // Membuat objek HttpURLConnection
            URL serverUrl = new URL(url);
            HttpURLConnection connection = (HttpURLConnection) serverUrl.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept", "application/json");
    
            // Menerima respon dari server
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();
    
            // Menghapus data lama dari tabel
            model.setRowCount(0);
    
            // Memasukkan data baru ke dalam tabel
            // Data JSON dikembalikan dalam format array of objects
            String[] dataArray = response.toString().split("\\},\\{");
    
            for (String data : dataArray) {
                // Membersihkan karakter "{" dan "}"
                data = data.replaceAll("\\{|\\}", "");
    
                // Memisahkan data dengan koma
                String[] fields = data.split(",");
    
                // Memastikan array memiliki cukup elemen sebelum mengaksesnya
                if (fields.length >= 2) {
                    // Menambahkan data ke dalam tabel, mengabaikan kolom ID
                    model.addRow(new Object[]{fields[1].split(":")[1], 
                                              fields[2].split(":")[1], 
                                              fields[3].split(":")[1],
                                              fields[4].split(":")[1],  
                                              fields[5].split(":")[1]});
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Terjadi kesalahan: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new DaftarPaketGUI();
            }
        });
    }
}
