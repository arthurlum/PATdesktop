import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class DaftarPesananGUI extends JFrame {

    private DefaultTableModel model;

    public DaftarPesananGUI() {
        setTitle("Daftar Pesanan Wisata");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        JTable table = new JTable();
        model = new DefaultTableModel();
        model.addColumn("ID Pesanan");
        model.addColumn("Nama");
        model.addColumn("Email");
        model.addColumn("Tanggal Trip");
        model.addColumn("Jumlah Orang");
        model.addColumn("Paket");
        model.addColumn("Usia");
        table.setModel(model);

        JScrollPane scrollPane = new JScrollPane(table);

        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(e -> {
            tampilkanPesanan();
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(refreshButton);

        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        add(panel);
        setVisible(true);

        tampilkanPesanan();
    }

    private void tampilkanPesanan() {
        try {
            String url = "http://localhost:8000/daftarpesanan"; // Ganti dengan URL server Anda
            URL serverUrl = new URL(url);
            HttpURLConnection connection = (HttpURLConnection) serverUrl.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept", "application/json");

            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();

            model.setRowCount(0);

            String[] dataArray = response.toString().split("\\},\\{");

            for (String data : dataArray) {
                data = data.replaceAll("\\{|\\}", "");
                String[] fields = data.split(",");
                model.addRow(new Object[]{
                        fields[0].split(":")[1].replaceAll("\"", ""), 
                        fields[1].split(":")[1].replaceAll("\"", ""), 
                        fields[2].split(":")[1].replaceAll("\"", ""), 
                        fields[3].split(":")[1].replaceAll("\"", ""),
                        fields[4].split(":")[1].replaceAll("\"", ""),
                        fields[5].split(":")[1].replaceAll("\"", ""), 
                        fields[6].split(":")[1].replaceAll("\"", "") 
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Terjadi kesalahan: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new DaftarPesananGUI();
            }
        });
    }
}
