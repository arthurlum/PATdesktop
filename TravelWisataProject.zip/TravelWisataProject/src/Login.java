import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.Base64;

public class Login extends JFrame {
    private JLabel usernameLabel, passwordLabel;
    private JTextField usernameField;
    private JTextField passwordField; // Menggunakan JTextField untuk input password
    private JButton loginButton;

    public Login() {
        setTitle("Login");
        setSize(300, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        usernameLabel = new JLabel("Username:");
        passwordLabel = new JLabel("Password:");
        usernameField = new JTextField(15);
        passwordField = new JTextField(15); // Menggunakan JTextField untuk input password
        loginButton = new JButton("Login");

        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(usernameLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        panel.add(usernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(passwordLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(loginButton, gbc);

        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = passwordField.getText(); // Mengambil password sebagai teks biasa

                try {
                    URL url = new URL("http://192.168.1.5:8000/login");
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("POST");
                    connection.setDoOutput(true);

                
                    String encodedCredentials = Base64.getEncoder().encodeToString((username + ":" + password).getBytes());
                    connection.setRequestProperty("Authorization", "Basic " + encodedCredentials);

                    String postData = "username=" + URLEncoder.encode(username, "UTF-8") +
                            "&password=" + URLEncoder.encode(password, "UTF-8");
                    OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream());
                    writer.write(postData);
                    writer.flush();

                    
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String response = reader.readLine();

                    
                    if (response.equals("Login Berhasil")) {
                        JOptionPane.showMessageDialog(Login.this, "Login Berhasil");
                    } else {
                        JOptionPane.showMessageDialog(Login.this, "Login Gagal");
                    }

                    
                    writer.close();
                    reader.close();
                    connection.disconnect();

                } catch (IOException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(Login.this, "Terjadi kesalahan server");
                }
            }
        });

        add(panel);

        setVisible(true);
    }

    public static void main(String[] args) {
        new Login();
    }
}
