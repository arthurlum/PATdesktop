import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class EditPaketGUI extends JFrame {

    private JTextField idField;
    private JTextField usernameField;
    private JTextField passwordField;
    private JTextField hargaPaketField;
    private JTextField jenisTripField;
    private JTextField listWisataField;

    public EditPaketGUI() {
        setTitle("Edit Paket Wisata");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(7, 2));

        JLabel idLabel = new JLabel("ID Paket:");
        idField = new JTextField();
        panel.add(idLabel);
        panel.add(idField);

        JLabel usernameLabel = new JLabel("Username:");
        usernameField = new JTextField();
        panel.add(usernameLabel);
        panel.add(usernameField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordField = new JTextField();
        panel.add(passwordLabel);
        panel.add(passwordField);

        JLabel hargaPaketLabel = new JLabel("Harga Paket:");
        hargaPaketField = new JTextField();
        panel.add(hargaPaketLabel);
        panel.add(hargaPaketField);

        JLabel jenisTripLabel = new JLabel("Jenis Trip:");
        jenisTripField = new JTextField();
        panel.add(jenisTripLabel);
        panel.add(jenisTripField);

        JLabel listWisataLabel = new JLabel("List Wisata:");
        listWisataField = new JTextField();
        panel.add(listWisataLabel);
        panel.add(listWisataField);

        JButton editButton = new JButton("Edit Paket");
        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editPaket();
            }
        });
        panel.add(editButton);

        add(panel);
        setVisible(true);
    }

    private void editPaket() {
        try {
            String id = idField.getText();
            String username = usernameField.getText();
            String password = passwordField.getText();
            String hargaPaket = hargaPaketField.getText();
            String jenisTrip = jenisTripField.getText();
            String listWisata = listWisataField.getText();

            String url = "http://localhost:8000/editpaket/" + id;
            URL serverUrl = new URL(url);
            HttpURLConnection connection = (HttpURLConnection) serverUrl.openConnection();
            connection.setRequestMethod("PUT");
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            connection.setDoOutput(true);

            // Mengonversi data ke format URL-encoded
            String postData = "username=" + URLEncoder.encode(username, "UTF-8") +
                              "&password=" + URLEncoder.encode(password, "UTF-8") +
                              "&harga_paket=" + URLEncoder.encode(hargaPaket, "UTF-8") +
                              "&jenis_trip=" + URLEncoder.encode(jenisTrip, "UTF-8") +
                              "&list_wisata=" + URLEncoder.encode(listWisata, "UTF-8");

            connection.getOutputStream().write(postData.getBytes());

            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String response = reader.readLine();
            reader.close();

            JOptionPane.showMessageDialog(this, response, "Edit Paket", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Terjadi kesalahan: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new EditPaketGUI();
            }
        });
    }
}
