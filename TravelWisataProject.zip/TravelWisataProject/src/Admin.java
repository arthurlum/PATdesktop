import javax.swing.*;
import java.awt.*;


public class Admin extends JFrame {

    public Admin() {
        // Mengatur layout frame menjadi GridLayout dengan 2 baris dan 3 kolom
        setLayout(new GridLayout(2, 3, 10, 10)); // 10 piksel jarak horizontal dan vertikal antara komponen

        // Membuat 6 tombol
        JButton button1 = new JButton("List Paket");
        JButton button2 = new JButton("Edit Data");
        JButton button3 = new JButton("Hapus Paket");
        JButton button4 = new JButton("List Pesanan");
    

        // Mengatur font dan ukuran tombol
        Font font = new Font("Arial", Font.BOLD, 18);
        button1.setFont(font);
        button2.setFont(font);
        button3.setFont(font);
        button4.setFont(font);
    

        // Menambahkan tombol-tombol ke dalam frame
        add(button1);
        add(button2);
        add(button3);
        add(button4);
    

        // Mengatur judul frame, ukuran, dan menampilkannya
        setTitle("Admin Base");
        setSize(500, 300); // Lebih lebar
        setLocationRelativeTo(null); // Menampilkan frame di tengah layar
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Menutup aplikasi ketika frame ditutup
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Admin();
            }
        });
    }
}
