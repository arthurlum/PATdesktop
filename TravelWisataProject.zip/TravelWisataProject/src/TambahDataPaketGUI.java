import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class TambahDataPaketGUI extends JFrame {

    public TambahDataPaketGUI() {
        // Setting frame
        setTitle("Tambah Data Paket");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel utama
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(7, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Komponen
        JLabel lblUsername = new JLabel("Username:");
        JTextField txtUsername = new JTextField();

        JLabel lblPassword = new JLabel("Password:");
        JPasswordField txtPassword = new JPasswordField();

        JLabel lblHargaPaket = new JLabel("Harga Paket:");
        JTextField txtHargaPaket = new JTextField();

        JLabel lblJenisTrip = new JLabel("Jenis Trip:");
        JTextField txtJenisTrip = new JTextField();

        JLabel lblListWisata = new JLabel("List Wisata:");
        JTextField txtListWisata = new JTextField(); // JTextField untuk memasukkan daftar wisata

        JButton btnTambah = new JButton("Tambah");

        // Menambahkan komponen ke panel
        panel.add(lblUsername);
        panel.add(txtUsername);
        panel.add(lblPassword);
        panel.add(txtPassword);
        panel.add(lblHargaPaket);
        panel.add(txtHargaPaket);
        panel.add(lblJenisTrip);
        panel.add(txtJenisTrip);
        panel.add(lblListWisata);
        panel.add(txtListWisata);
        panel.add(btnTambah);

        // Event listener untuk tombol Tambah
        btnTambah.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tambahDataPaket(txtUsername.getText(), new String(txtPassword.getPassword()),
                        Double.parseDouble(txtHargaPaket.getText()), txtJenisTrip.getText(),
                        txtListWisata.getText());
            }
        });

        // Menambahkan panel ke frame
        add(panel);

        // Menampilkan frame
        setVisible(true);
    }

    private void tambahDataPaket(String username, String password, double hargaPaket, String jenisTrip, String listWisata) {
        try {
           
            String data = "{\"username\":\"" + username + "\","
                    + "\"password\":\"" + password + "\","
                    + "\"harga_paket\":" + hargaPaket + ","
                    + "\"jenis_trip\":\"" + jenisTrip + "\","
                    + "\"list_wisata\":\"" + listWisata + "\"}";

            // URL server
            String url = "http://localhost:8000/tambahpaket"; // Ganti port dengan port server Anda

            // Membuat objek HttpURLConnection
            URL serverUrl = new URL(url);
            HttpURLConnection connection = (HttpURLConnection) serverUrl.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            // Mengirim data ke server
            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = data.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            // Menerima respon dari server
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                // Respon sukses
                JOptionPane.showMessageDialog(this, "Tambah Paket Berhasil", "Sukses", JOptionPane.INFORMATION_MESSAGE);
            } else {
                // Respon gagal
                JOptionPane.showMessageDialog(this, "Tambah Paket Gagal", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Terjadi kesalahan: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new TambahDataPaketGUI();
            }
        });
    }
}
